#!/bin/bash

# Define a list of files
files=("PIN.fasta" "CcdB.fasta" "Fic.fasta" "Gp49.fasta" "HicA_toxin.fasta" "HigB-like_toxin.fasta" "HipA_C.fasta"" HOK_GEF.fasta" "Ldr_toxin.fasta" "ParE_toxin.fasta" "PemK_toxin.fasta" "PhoH.fasta" "PIN_3.fasta")

#files=("ParE_toxin.fasta")

# Loop through each file in the list
for file in "${files[@]}"
do
   echo "running toxins for $file"
   awk -v RS=">" -v FS="\n" -v ORS="" '$1 ~ /\.toxin$/ {print ">"$0}' $file > "$file.new.toxin.fasta"
   muscle -in "$file.new.toxin.fasta" -out "$file.new.toxin.afa"
   FastTree < "$file.new.toxin.afa" > "$file.new.toxin.nwk"
   #sed -i 's/\.toxin//g' "$file.toxin.afa"
   #muscle -maketree -in "$file.toxin.afa" -out "$file.toxin.phy"
   #seqret fasta::"$file.toxin.afa" nexus::"$file.toxin.nexus"
	

   echo "running antitoxins for $file"
   # repeat for antitoxins
   awk -v RS=">" -v FS="\n" -v ORS="" '$1 ~ /\.antitoxin$/ {print ">"$0}' $file > "$file.new.antitoxin.fasta"
   muscle -in "$file.new.antitoxin.fasta" -out "$file.new.antitoxin.afa"
   FastTree < "$file.new.toxin.afa" > "$file.new.toxin.nwk"
   #sed -i 's/\.toxin//g' "$file.antitoxin.afa"
   #muscle -maketree -in "$file.antitoxin.afa" -out "$file.antitoxin.phy"
   #seqret fasta::"$file.antitoxin.afa" nexus::"$file.antitoxin.nexus"
   echo ""  # Just for readability
done

