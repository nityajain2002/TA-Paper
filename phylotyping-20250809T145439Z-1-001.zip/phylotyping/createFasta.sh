#!/bin/bash

output_file="chosenSeqs.fasta"
# loop to grab sequence info

for accession in "$@"; do
	#file_path="${accession}_dataset/ncbi_dataset/data/*.fna"
	file_path="${accession}_dataset/ncbi_dataset/data"

	if [ -d "$file_path" ]; then
		fnaFile=$(find "$file_path" -name "*fna" | head -n 1)

		if [ -f "$fnaFile" ]; then
			#cat "$fnaFile" >> "$output_file"
			awk 'BEGIN {p=1} /^>/ && p==1 {print; p=0} !/^>/ && p==0 {print}' "$fnaFile" >> "$output_file" # supposed to only take the first seq but i think its doing all of em
			echo "genomic sequence for $accession added"
		else
			echo "file not found for accession: $accession"
		fi
	else
		echo "directory not found for $accession"
	fi
done
