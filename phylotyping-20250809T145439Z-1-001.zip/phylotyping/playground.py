import random, subprocess
from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt

# map input data to data parsing format0
def inputData(filePath):
    file = open(filePath)
    phyloSets = {}
    for line in file:
        x = line.split('\t')
        y = x[0].split('_')
        gAccession = '_'.join([y[0], y[1]])
        phylotype = x[1].strip()
        if phylotype not in phyloSets.keys():
            phyloSets[phylotype] = [gAccession]
        else:
            phyloSets[phylotype].append(gAccession)
    return phyloSets
#for i, j in phyloSets.items():
#    print(i, len(j))

# pull accessions for fasta file
def chooseAccessions(phyloSets):
    chosenOnes = list(set(phyloSets['G'])) + list(set(phyloSets['B2'])) + list(set(phyloSets['A'])) + list(set(phyloSets['F'])) + list(set(phyloSets['D']))

    randomB1 = random.sample(list(set(phyloSets['B1'])), min(10, len(phyloSets['B1'])))
    randomE = random.sample(list(set(phyloSets['E'])), min(14, len(phyloSets['E'])))

    chosenOnes = phyloSets['G'] + phyloSets['B2'] + phyloSets['A'] + phyloSets['F'] + phyloSets['D'] + randomB1 + randomE
    print(len(chosenOnes))
    return chosenOnes

# get seqs + assemble FASTA file
def grabSeqs(chosenOnes, outFile):
    Entrez.email = "njain14@ucsc.edu"
    id_list = ",".join(chosenOnes)
    counter = 0
    if counter == 0:
        with Entrez.efetch(db="nuccore", id=id_list, rettype="fasta") as handle:
            with open(outFile, "w") as out_handle:
                out_handle.write(handle.read())
                counter += 1

# main
#x = inputData('output.txt')
#y = chooseAccessions(x)
#print(y)
#out = grabSeqs(y, 'phyloSeqs.fasta')
#print(out)
#inputBash = " ".join(y)
#sinputBash = ["GCA_002853715.1", "GCA_000013265.1"]
#ubprocess.run(["bash", "createFasta.sh", *y])

# mlst results (pulled from mlst-output.txt): 

dinB = (1,1,1,1,2,2,5,5,5,5,5,5,5,5,5,5,9,10,10,10,10,10,10,13,13,13,13,19,19,23,23,59,59,59,59,59,59,59,59,59,59,68,68,68,97)	
icdA = (1,1,1,1,1,2,2,2,2,3,3,3,3,3,3,3,3,3,9,9,9,9,11,11,39,39,39,39,39,39,41,47,47,47,110,110,110,110,110,110,110,110,110,110,110,110,110,176)	
pabB = (2,2,2,2,4,4,4,4,4,4,4,4,4,4,4,4,7,7,7,7,8,8,11,11,11,11,15,21,23,23,25,25,88,88,88,88,88,88,88,88,88,88,88,88,88,98,99,99)	
polB = (1,1,1,1,3,3,3,3,7,12,12,15,15,16,16,16,16,20,20,52,52,52,52,52,52,52,56,56,56,63,63,63,63,63,63,63,63,63,63,63,63,83,83,92,123)	
putP = (1,1,1,1,4,6,6,6,7,7,9,9,9,9,10,10,12,12,12,12,14,14,23,41,41,84,84,84,84,84,84,93,93,93,93,93,93,93,93,93,93,93,93,93,212)	
trpA = (1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,9,9,11,11,15,15,22,22,23,25,25,29,84,84,84,84,84,84,84,84,84,84,84,84,84,126)	
trpB = (2,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,6,6,7,7,8,8,8,8,10,10,10,10,20,31,31,86,86,86,86,86,86,86,86,86,86,86,86,86,115)	
uidA = (1,1,1,1,2,2,2,2,2,2,9,11,11,12,12,13,13,13,13,18,19,19,19,19,40,58,58,58,66,66,66,66,66,66,66,83,83,83,83,83,83,83,83,83,83,83,83,83)

labels = ['dinB', 'icdA', 'pabB', 'polB', 'putP', 'trpA', 'trpB', 'uidA']
sizes = [len(dinB), len(icdA), len(pabB), len(polB), len(putP), len(trpA), len(trpB), len(uidA)]

plt.figure(figsize=(8,8))
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
plt.title('MLSTs Distribution')
plt.show()