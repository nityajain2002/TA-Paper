#!/bin/bash

# Check if an input file is provided as an argument
if [ $# -ne 1 ]; then
    echo "Usage: $0 <input_file>"
    exit 1
fi

input_file=$1

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: Input file '$input_file' not found."
    exit 1
fi

# Loop through each accession number in the input file
while IFS= read -r accession_number; do
    # Step 1: Download the dehydrated zip archive
    datasets download genome accession "$accession_number" --dehydrated --filename "${accession_number}_dataset.zip"

    # Step 2: Unzip the dehydrated zip archive to a directory
    unzip -o "${accession_number}_dataset.zip" -d "${accession_number}_dataset"

    # Step 3: Rehydrate
    datasets rehydrate --directory "${accession_number}_dataset/"

    # Step 4: Find the .fna file in the directory
    fna_file=$(find "${accession_number}_dataset" -type f -name "*.fna")

    # Check if .fna file is found
    if [ -z "$fna_file" ]; then
        echo "Error: .fna file not found in ${accession_number}_dataset directory"
        continue
    fi

    # Run ezclermont
    ezclermont "$fna_file" >> output.txt
done < "$input_file"

echo "EzClermont analysis completed. Results are saved in output.txt"

