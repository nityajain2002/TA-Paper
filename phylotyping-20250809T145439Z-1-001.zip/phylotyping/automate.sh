#!/bin/bash

# Check if the accession number is provided as an argument
if [ $# -eq 0 ]; then
    echo "Usage: $0 <genome_accession_number>"
    exit 1
fi

# Accession number provided as the first argument
accession_number=$1

# Step 1: Download the dehydrated zip archive
datasets download genome accession "$accession_number" --dehydrated --filename "${accession_number}_dataset.zip"

# Step 2: Unzip the dehydrated zip archive to a directory
unzip "${accession_number}_dataset.zip" -d "${accession_number}_dataset"

# Step 3: Rehydrate
datasets rehydrate --directory "${accession_number}_dataset/"

# Step 4: find fna file
fna_file=$(find "${accession_number}_dataset" -type f -name "*.fna")

# ezclermont
if [-z "$fna_file"]; then
	exit 1
fi

ezclermont $fna_file > output.txt

