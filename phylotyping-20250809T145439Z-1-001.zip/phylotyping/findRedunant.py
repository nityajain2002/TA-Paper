import pandas as pd
df = pd.read_csv('Toxins.csv')

# filtering out duplicate contigs

duplicates = df[df.duplicated(subset=['Contig','Hit Name'], keep=False)]
#duplicates.to_csv('duplicate-Toxins.csv', index=False)

# group by # of antitoxins
# filter out the ones w/ two pairs (ie. both upstream & downstream)

multipleAntitoxins = duplicates[(duplicates['Upstream'] != '-') & (duplicates['Downstream'] != '-')]
removeDuplicates = ~duplicates.isin(multipleAntitoxins).all(axis=1)
singleAntitoxins = duplicates[removeDuplicates]
#singleAntitoxins.to_csv('singleAntitoxisn-Toxins.csv', index=False)
# prepare for MSA
# split filtered data frame into TA families & create fasta file

def uniqueFastaFile(hitName): # to streamline process, 14 TA familes
    hitdf = singleAntitoxins[singleAntitoxins['Hit Name'] == hitName]
    inFile = hitName + '.fasta'
    with open(inFile, 'w') as file:
        for index, row in hitdf.iterrows():
            headerT = f">{hitName + '_' + str(index)}.toxin\n"
            headerA = f">{hitName + '_' + str(index)}.antitoxin\n"
            
            seqT = f"{row['Hit']}\n"
            seqA = ''
            if row['Upstream'] != '-':
                seqA = f"{row['Upstream']}\n"
            else:
                seqA = f"{row['Downstream']}\n"
            
            file.write(headerT)
            file.write(seqT)
            file.write(headerA)
            file.write(seqA)

hitNames = singleAntitoxins['Hit Name'].unique() # my input list
for i in hitNames:
    uniqueFastaFile(i) 

# group by PTUs
ptuDF = pd.read_csv('NCBI2023_PTU - NCBI2023_PTU.csv')
print(ptuDF.columns)
